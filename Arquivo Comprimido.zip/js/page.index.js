//========================================
// SEND PIC IFRAME
//========================================
$(function () {

    if (typeof localStorage.user_id === "undefined") {
        return;
    }

});
